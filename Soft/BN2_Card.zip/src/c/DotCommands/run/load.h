#ifndef _LOAD_H
#define _LOAD_H

extern void load_bas(void);
extern void load_dot(void);
extern void load_nex(void);
extern void load_snap(void);
extern void load_tap(void);

#endif

#ifndef _LIST_H
#define _LIST_H

extern void list_generate(void);

#endif

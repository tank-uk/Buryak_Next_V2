#ifndef USER_H
#define USER_H

extern void user_break(void);

#endif

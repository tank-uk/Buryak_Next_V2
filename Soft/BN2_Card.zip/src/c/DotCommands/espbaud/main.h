#ifndef MAIN_H
#define MAIN_H

extern unsigned char buffer[256];

extern int m_printf(char *fmt, ...);

#endif

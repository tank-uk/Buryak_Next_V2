#ifndef _USER_INTERACTION_H
#define _USER_INTERACTION_H

extern void user_interaction(void);

#endif

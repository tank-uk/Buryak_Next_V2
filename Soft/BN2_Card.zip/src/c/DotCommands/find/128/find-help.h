#ifndef _FIND_HELP_H
#define _FIND_HELP_H

extern unsigned char find_help[];
extern unsigned char find_version[];

#endif

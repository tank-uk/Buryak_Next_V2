#ifndef _ERRORS_H
#define _ERRORS_H

extern unsigned char err_out_of_memory[];
extern unsigned char err_invalid_parameter[];
extern unsigned char err_invalid_option[];
extern unsigned char err_break_into_program[];
extern unsigned char err_depth_order[];

#endif

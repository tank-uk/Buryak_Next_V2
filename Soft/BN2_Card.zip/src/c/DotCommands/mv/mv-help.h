#ifndef _MV_HELP_H
#define _MV_HELP_H

extern unsigned char mv_help[];
extern unsigned char mv_version[];

#endif

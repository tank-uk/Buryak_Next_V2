Palette Cycling on the ZX Next Enhanced ULA

Wondeful music by Ch41ns4w called youko which is 
available here:

http://zxart.ee/eng/authors/c/ch41ns4w/

This small demo shows Amiga like palette cycling on the 
ULA layer (aka Spectrum mode). Uploading a custom palette 
from an increasing offset lets you "animate" the palette
and using specially coloured images can give make the 
scene really come alive.

I simply picked a range of colours in a gradiant and store 
the values in a memory block.

Here are few images that I've drawn or downloaded from the 
internet and coloured in using ZX paintbrush. Tochi image from 
Busy's "Tochi" demo and recoloured for this affect. 

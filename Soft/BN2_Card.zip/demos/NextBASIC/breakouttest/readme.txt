very early test using sprites and basic

still some bugs!

dms
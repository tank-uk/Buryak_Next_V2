A simple 256 colour slideshow, loads BMPs from SD. All the files 
are stored in the bitmaps folder.  
**NOTE**: BMPs _MUST_ be stored with the _reversed row order_ option.

Loader.bas - loads the bmps as a slideshow, space for next

LoaderMusic.bas - same as above but with some music

Hold Q to quit
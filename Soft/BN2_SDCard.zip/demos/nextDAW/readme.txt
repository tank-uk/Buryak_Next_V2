NextDAW
Copyright (c) 2018 Gari Biasillo
All Rights Reserved

This product is protected by copyright and distributed under
licenses restricting copying, distribution and decompilation.

Thank you for trying out the premier music creation software for the Spectrum Next!
This is a fully functional time limited version of NextDAW, and save functionality removed.

If you like what you see (and hear!) please support by purchasing a unrestricted copy at nextdaw.biasillo.com

Thank you!


Contents

NextDAWDemo
+- NextDAWDemo.nex				(The executable)
+- NDAWPLAY             		(move this to the BIN directory at the root)
+- SongProject					(Demo song projects to load in NextDAW)
   +- Dont't Go.DAW
   +- DontYouWantMe.DAW
   +- Only You.DAW
+- SongDotPlayer				(Songs that can be played using the NDAWPLAY dot command)
   +- Dont't Go.NDR
   +- DontYouWantMe.NDR
   +- Only You.NDR
+- Docs
   +- NextDAW User Guide.pdf	(The user guide)

Selecting NextDAWDemo.nex from NextZXOS will run the software
Selecting an .NDR file will run it using the NDAWPLAY dot command, which must be placed in your BIN directory.

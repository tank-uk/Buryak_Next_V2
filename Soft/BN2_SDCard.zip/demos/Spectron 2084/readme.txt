Spectron 2084 is a classic golden age arcade game for the ZX Spectrum Next, with a focus on faithfulness to the arcade version, as well as control flexibility. All controls modes will be available: Single sticks, twin sticks and keyboard.

Here I present a runnable teaser of the attract screen. No playability yet, but you should get a sense of how faithfulness to the arcade version the game will be.

https://www.specnext.com/latestdistro/

50Hz is currently supported on both VGA and HDMI, as well as 60Hz on VGA. Full 60Hz including HDMI will be supported in the released game.

Accompanying video: https://youtu.be/FJHyNFhjDqY

Enjoy!

Robin Verhagen-Guest
SevenFFF
May 2018

https://seven-fff.com/Spectron2084/
spectron@seven-fff.com